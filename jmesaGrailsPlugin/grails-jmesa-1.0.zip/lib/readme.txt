drop the following jar files here.
I remove the common jar file between grails and jmesa. at least,remove the groovy lib and Spring lib.
---------------------------------
jmesa.jar
core-renderer-R8prel.jar
itext-paulo-155.jar
jcl104-over-slf4j-1.4.3.jar
jexcel-2.6.6.jar
poi-3.0-FINAL.jar
slf4j-pi-1.4.3.jar
slf4j-log4j12-1.4.3.jar
tagsoup.-1.1.3.jar

